package com.fitness.aiservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
