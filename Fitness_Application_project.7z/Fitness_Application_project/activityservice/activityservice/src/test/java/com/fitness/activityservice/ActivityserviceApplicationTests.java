package com.fitness.activityservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActivityserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
