package com.fitness.userservices.model;

public enum UserRole {
        USER, ADMIN
}
